dic={}

def cadastra():
    numero=int(input("Qual numero deseja adicionar:"))
    if numero in dic:
        print("Ja esta cadastrado")
    else:
        nome=input("Qual é a tarefa:").title()
        dic[numero]=nome
def alterar():
    qual=int(input("Qual numero deseja alterar:"))
    if qual in dic:
        tarefa_n=input("Qual sera a nova tarefa:").title()
        dic[qual]=tarefa_n
def excluir():
    qual=int(input("Qual numero deseja excluir:"))
    if qual in dic:
        dic.pop(qual)
    else:
        print("Este numero não esta")
def printar():
    print(f"As informaçoes organizadas{sorted(dic.items())}")
while True:
    lista=[]
    print("#####"*10)
    print("Opções: C-Cadastrar tarefa")
    print("        A-Alterar")
    print("        E-Excluir")
    print("        P-Pesquisar")
    print("        S-Sair")
    print("#####"*10)
    opcoe=input("Qual dessas opções deseja escolher:").upper()
    if opcoe=="C":
        cadastra()
    if opcoe=="A":
        alterar()
    if opcoe=="E":
        excluir()
    if opcoe=="P":
        printar()
    if opcoe=="S":
        print("Saindo")
        break