empresa={}



while True:
    lista=[]
    print("#####"*10)
    print("Opções: C-Cadastrar funcionario")
    print("        A-Alterar")
    print("        E-Excluir")
    print("        P-Pesquisar")
    print("        S-Sair")
    print("#####"*10)
    opcoe=input("Qual dessas opções deseja escolher:").upper()
    if opcoe=="C":
        numero=int(input("Qual numero do funcionario:"))
        nome=input("Qual é o nome do funcionario:").title()
        lista.append(nome)
        cargo=input("Qual é o seu cargo:").title()
        lista.append(cargo)
        empresa[numero]=lista
    if opcoe=="A":
        qual=input("Deseja alterar o funcionariou ou o cargo- F ou C:").upper()
        if qual=="F":
            novo_n=int(input("Qual é o numero que deseja alterar:"))
            if novo_n in empresa:
                nomenal=input("Qual sera o novo funcionario:").title()
                empresa[novo_n][0]=nomenal
            else:
                print("Este numero não esta cadastrado.")
        if qual=="C":
            novo_n=int(input("Qual é o numero que deseja alterar:"))
            if novo_n in empresa:
                cargonal=input("Qual sera o novo cargo:").title()
                empresa[novo_n][1]=cargonal
            else:
                print("Este numero não esta cadastrado.")
    if opcoe=="E":
        sera=int(input("Qual numero deseja remover:"))
        empresa.pop(sera)
    if opcoe=="P":
        print(empresa)
    if opcoe=="S":
        print("Saindo ")
        break