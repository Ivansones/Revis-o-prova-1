lista=('botafogo','fortaleza','flamengo','palmeiras','são paulo','cruzeiro','bahia','athletico-PR','athletico-MG','vasco','bragantino','juventude','gremio','criciuma','internacional','vitoria',
       'corinthias','fluminense','cuiaba','athletico-GO')

print(f"Os primeiros colocados são {lista[0:5]}")
print(f"Os ultimos colocados são {lista[16:20]}")
print(f"A lista em ordem alfabetica é {sorted(lista)}")
posicao=lista.index("criciuma")
certo=posicao+1
print(f"A posição de criciuma é {certo}")